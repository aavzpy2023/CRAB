import argparse
import itertools
import sys
import warnings
from pathlib import Path

import joblib
import pandas as pd
import xgboost as xgb


# The model outputs P(ncRNA); a sequence is ncRNA when it exceeds this cutoff.
NCRNA_THRESHOLD = 0.546569037437439


def generate_kmers() -> list[str]:
    """Generates all 64 static 3-mer DNA combinations."""
    nucleotides = ["A", "C", "G", "T"]
    return ["".join(p) for p in itertools.product(nucleotides, repeat=3)]


def extract_features(sequence: str, kmers: list[str]) -> dict[str, float]:
    """Counts non-overlapping 3-mers (codons) and strictly normalizes them."""
    counts = {k: 0.0 for k in kmers}
    seq_len = len(sequence)
    if seq_len < 3:
        return counts

    trinucs = [sequence[i : i + 3] for i in range(0, seq_len - 2, 3)]
    total = len(trinucs)
    
    if total == 0:
        return counts

    for kmer in trinucs:
        if kmer in counts:
            counts[kmer] += 1.0

    for k in counts:
        counts[k] /= total

    return counts


def run_inference(records: list[tuple[str, str]], model_path: str) -> list[dict]:
    """Loads XGBoost model, runs prediction and applies classification threshold."""
    if not Path(model_path).is_file():
        raise FileNotFoundError(f"Model file not found: {model_path}")

    kmers = generate_kmers()
    features_list = [extract_features(seq, kmers) for _, seq in records]
    df = pd.DataFrame(features_list, columns=kmers)

    print(f"[*] Loading model from {model_path}...")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=UserWarning)
        model = joblib.load(model_path)
    dmatrix = xgb.DMatrix(df)
    
    print("[*] Running inference...")
    probs = model.predict(dmatrix)

    results = []
    for (header, seq), prob in zip(records, probs):
        p_ncrna = float(prob)
        float_prob = 1.0 - p_ncrna
        classification = "ncRNA" if p_ncrna > NCRNA_THRESHOLD else "coding_protein"
        seq_id = header.split()[0] if header else "unknown"
        results.append(
            {
                "seq_id": seq_id,
                "probabilidad_coding": round(float_prob, 4),
                "prediccion_label": classification,
            }
        )
    return results


def setup_argparse() -> argparse.Namespace:
    """
    Configures CLI arguments for the standalone inference script.
    """
    parser = argparse.ArgumentParser(description="CRAB Standalone Researcher CLI")
    parser.add_argument(
        "-p",
        "--path",
        required=True,
        help="Input FASTA file path",
    )
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Output directory path",
    )
    parser.add_argument(
        "-m",
        "--model",
        default="Bacteria.pkl",
        help="Model file path (default: Bacteria.pkl)",
    )
    return parser.parse_args()


def parse_fasta_file(filepath: str):
    """
    Yields (header, sequence) tuples from a FASTA file.
    Automatically standardizes sequences to uppercase DNA (U -> T).
    Concatenates multi-line sequences safely.
    """
    path = Path(filepath)
    if not path.is_file():
        raise FileNotFoundError(f"FASTA file not found: {filepath}")

    header = None
    seq_lines = []

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            if line.startswith(">"):
                if header is not None:
                    # Normalization: Upper case and RNA(U) to DNA(T) conversion
                    seq = "".join(seq_lines).upper().replace("U", "T")
                    yield header, seq
                header = line[1:].strip()
                seq_lines = []
            else:
                seq_lines.append(line)

        # Yield the final sequence record
        if header is not None:
            seq = "".join(seq_lines).upper().replace("U", "T")
            yield header, seq


def export_csv(results: list[dict], output_dir: str):
    """Exports inference results to predictions.csv in the given directory."""
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    csv_path = out_path / "predictions.csv"
    
    df = pd.DataFrame(results)
    df.to_csv(csv_path, index=False)
    print(f"[*] Results successfully written to {csv_path}")


def main():
    try:
        args = setup_argparse()
        print(f"[*] Starting standalone processing for: {args.path}")

        records = list(parse_fasta_file(args.path))
        print(f"[*] Parsed {len(records)} sequences successfully.")

        results = run_inference(records, args.model)
        print(f"[*] Inference completed for {len(results)} sequences.")

        export_csv(results, args.output)

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()